CKEDITOR.editorConfig = function (config) {
  CKEDITOR.config.toolbar_mini =
    [
        ["Undo","Redo","-","Find","Replace","-","SelectAll","RemoveFormat", "-" ,"Scayt"],
        ["Bold","Italic","Underline","Strike","-"],
        ["NumberedList","BulletedList","-","Outdent","Indent"],
        ["JustifyLeft","JustifyCenter","JustifyRight","JustifyBlock"],
        ["Link","Unlink"],
        ["Image","Table","HorizontalRule"],
        ["Styles","Format","Font","FontSize"],
        ["TextColor","BGColor"]

    ];
}
;
